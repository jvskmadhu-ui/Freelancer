import { Link } from '@tanstack/react-router';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { MessageSquare } from 'lucide-react';
import { useGetUnreadMessagesForProject } from '../../hooks/useQueries';
import type { Project } from '../../backend';

interface ConversationListItemProps {
  order: Project;
  currentUserPrincipal: string;
}

export default function ConversationListItem({ order, currentUserPrincipal }: ConversationListItemProps) {
  const { data: unreadMessageIds = [] } = useGetUnreadMessagesForProject(order.id, currentUserPrincipal);
  const unreadCount = unreadMessageIds.length;

  const lastMessage = order.messages.length > 0 ? order.messages[order.messages.length - 1] : null;
  const lastMessagePreview = lastMessage
    ? lastMessage.content.length > 60
      ? `${lastMessage.content.slice(0, 60)}...`
      : lastMessage.content
    : 'No messages yet';

  return (
    <Link key={order.id} to="/orders/$orderId/messages" params={{ orderId: order.id }} className="focus-visible:outline-none">
      <Card className="cursor-pointer transition-interactive hover:shadow-lg hover:scale-[1.01] hover:border-primary/50 focus-within:ring-2 focus-within:ring-ring active:scale-[0.99]">
        <CardHeader>
          <CardTitle className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              {order.title}
            </div>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="ml-auto">
                {unreadCount} new
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground line-clamp-2">{lastMessagePreview}</p>
          <p className="text-xs text-muted-foreground mt-2">{order.messages.length} total messages</p>
        </CardContent>
      </Card>
    </Link>
  );
}
