import { Card } from '../ui/card';
import { formatDistanceToNow } from 'date-fns';
import type { Message } from '../../backend';
import EmptyState from '../common/EmptyState';

interface MessageThreadProps {
  messages: Message[];
  currentUserPrincipal: string;
}

export default function MessageThread({ messages, currentUserPrincipal }: MessageThreadProps) {
  if (messages.length === 0) {
    return <EmptyState title="No messages yet" description="Start the conversation" />;
  }

  return (
    <div className="space-y-3 max-h-[500px] overflow-y-auto">
      {messages.map((message) => {
        const isCurrentUser = message.sender.toText() === currentUserPrincipal;
        return (
          <Card
            key={message.id}
            className={`p-4 ${isCurrentUser ? 'ml-auto bg-primary/5' : 'mr-auto'} max-w-[80%]`}
          >
            <p className="text-sm">{message.content}</p>
            <p className="text-xs text-muted-foreground mt-2">
              {formatDistanceToNow(new Date(Number(message.timestamp) / 1000000), { addSuffix: true })}
            </p>
          </Card>
        );
      })}
    </div>
  );
}
