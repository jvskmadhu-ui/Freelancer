import { Link, useNavigate } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '../../hooks/useCurrentUser';
import LoginButton from '../auth/LoginButton';
import { Button } from '../ui/button';
import { Menu, Briefcase, User, LayoutDashboard } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '../ui/sheet';
import { Role } from '../../backend';
import { useState } from 'react';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAuthenticated = !!identity;
  const isClient = userProfile?.role === Role.client;
  const isFreelancer = userProfile?.role === Role.freelancer;
  const isAdmin = userProfile?.role === Role.admin;

  const handleDashboardClick = () => {
    if (isAdmin) {
      navigate({ to: '/dashboard/admin' });
    } else if (isFreelancer) {
      navigate({ to: '/dashboard/freelancer' });
    } else if (isClient) {
      navigate({ to: '/dashboard/client' });
    }
    setMobileMenuOpen(false);
  };

  const NavLinks = () => (
    <>
      <Link
        to="/"
        className="text-sm font-medium hover:text-primary transition-colors"
        onClick={() => setMobileMenuOpen(false)}
      >
        Browse Gigs
      </Link>
      {isAuthenticated && (
        <button
          onClick={handleDashboardClick}
          className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-2"
        >
          <LayoutDashboard className="h-4 w-4" />
          Dashboard
        </button>
      )}
      {isFreelancer && (
        <Link
          to="/services/new"
          className="text-sm font-medium hover:text-primary transition-colors"
          onClick={() => setMobileMenuOpen(false)}
        >
          Create Gig
        </Link>
      )}
    </>
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <Link to="/" className="flex items-center gap-2">
              <Briefcase className="h-6 w-6 text-primary" />
              <span className="font-bold text-xl">FreelanceHub</span>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <NavLinks />
            </nav>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated && userProfile && (
              <Link to="/profile" className="hidden md:flex items-center gap-2 text-sm">
                <User className="h-4 w-4" />
                <span>{userProfile.name}</span>
              </Link>
            )}
            <div className="hidden md:block">
              <LoginButton />
            </div>
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <nav className="flex flex-col gap-4 mt-8">
                  <NavLinks />
                  {isAuthenticated && userProfile && (
                    <Link
                      to="/profile"
                      className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-2"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <User className="h-4 w-4" />
                      {userProfile.name}
                    </Link>
                  )}
                  <div className="pt-4 border-t">
                    <LoginButton />
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t py-6 md:py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} FreelanceHub. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Built with ❤️ using{' '}
            <a
              href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-primary transition-colors"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}
