import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Star, Clock } from 'lucide-react';
import type { Service } from '../../backend';

interface ServiceCardProps {
  service: Service;
}

export default function ServiceCard({ service }: ServiceCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow h-full">
      <CardHeader>
        <CardTitle className="line-clamp-2">{service.name}</CardTitle>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="px-2 py-1 bg-secondary rounded-md text-xs">{service.category}</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-3">{service.description}</p>
        <div className="flex items-center justify-between pt-3 border-t">
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium">{service.averageRating.toFixed(1)}</span>
            <span className="text-xs text-muted-foreground">({service.reviews.length})</span>
          </div>
          <div className="text-lg font-bold">${Number(service.price).toFixed(2)}</div>
        </div>
        {service.duration && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>{service.duration}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
