import { Badge } from '../ui/badge';
import { Status } from '../../backend';

interface OrderStatusBadgeProps {
  status: Status;
}

export default function OrderStatusBadge({ status }: OrderStatusBadgeProps) {
  const getVariant = () => {
    switch (status) {
      case Status.placed:
        return 'secondary';
      case Status.inProgress:
        return 'default';
      case Status.delivered:
        return 'outline';
      case Status.completed:
        return 'default';
      default:
        return 'secondary';
    }
  };

  const getLabel = () => {
    switch (status) {
      case Status.placed:
        return 'Placed';
      case Status.inProgress:
        return 'In Progress';
      case Status.delivered:
        return 'Delivered';
      case Status.completed:
        return 'Completed';
      default:
        return String(status);
    }
  };

  return <Badge variant={getVariant()}>{getLabel()}</Badge>;
}
