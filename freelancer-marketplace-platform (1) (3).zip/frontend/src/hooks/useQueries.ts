import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { Service, Project, Message, Review, Profile } from '../backend';

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: Profile) => {
      if (!actor) throw new Error('Actor not available');
      await actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useGetServices() {
  const { actor, isFetching } = useActor();

  return useQuery<Service[]>({
    queryKey: ['services'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getServices();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetService(serviceId: string | undefined) {
  const { actor, isFetching } = useActor();

  return useQuery<Service | null>({
    queryKey: ['service', serviceId],
    queryFn: async () => {
      if (!actor || !serviceId) return null;
      return actor.getService(serviceId);
    },
    enabled: !!actor && !isFetching && !!serviceId,
  });
}

export function useAddService() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { name: string; category: string; description: string; price: bigint; duration: string | null }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addService(data.name, data.category, data.description, data.price, data.duration);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['services'] });
    },
  });
}

export function useUpdateService() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ serviceId, updated }: { serviceId: string; updated: Service }) => {
      if (!actor) throw new Error('Actor not available');
      await actor.updateService(serviceId, updated);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['services'] });
      queryClient.invalidateQueries({ queryKey: ['service', variables.serviceId] });
    },
  });
}

export function useDeleteService() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (serviceId: string) => {
      if (!actor) throw new Error('Actor not available');
      await actor.deleteService(serviceId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['services'] });
    },
  });
}

export function useGetUserServices(userPrincipal: string | undefined) {
  const { actor, isFetching } = useActor();

  return useQuery<Service[]>({
    queryKey: ['userServices', userPrincipal],
    queryFn: async () => {
      if (!actor || !userPrincipal) return [];
      const principal = { toText: () => userPrincipal } as any;
      return actor.getUserServices(principal);
    },
    enabled: !!actor && !isFetching && !!userPrincipal,
  });
}

export function useGetProject(projectId: string | undefined) {
  const { actor, isFetching } = useActor();

  return useQuery<Project | null>({
    queryKey: ['project', projectId],
    queryFn: async () => {
      if (!actor || !projectId) return null;
      return actor.getProject(projectId);
    },
    enabled: !!actor && !isFetching && !!projectId,
  });
}

export function useGetProjectFeed(userPrincipal: string | undefined) {
  const { actor, isFetching } = useActor();

  return useQuery<Project[]>({
    queryKey: ['projectFeed', userPrincipal],
    queryFn: async () => {
      if (!actor || !userPrincipal) return [];
      const principal = { toText: () => userPrincipal } as any;
      return actor.getProjectFeed(principal);
    },
    enabled: !!actor && !isFetching && !!userPrincipal,
  });
}

export function useCreateOrderWithInternalPayments() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { freelancer: any; title: string; price: bigint; serviceIds: string[] | null }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createOrderWithInternalPayments(data.freelancer, data.title, data.price, data.serviceIds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projectFeed'] });
    },
  });
}

export function useGetProjectMessages(projectId: string | undefined) {
  const { actor, isFetching } = useActor();

  return useQuery<Message[]>({
    queryKey: ['projectMessages', projectId],
    queryFn: async () => {
      if (!actor || !projectId) return [];
      return actor.getProjectMessages(projectId);
    },
    enabled: !!actor && !isFetching && !!projectId,
  });
}

export function useAddMessage() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ projectId, content }: { projectId: string; content: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addMessage(projectId, content);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['projectMessages', variables.projectId] });
      queryClient.invalidateQueries({ queryKey: ['project', variables.projectId] });
    },
  });
}

export function useGetServiceReviews(serviceId: string | undefined) {
  const { actor, isFetching } = useActor();

  return useQuery<Review[]>({
    queryKey: ['serviceReviews', serviceId],
    queryFn: async () => {
      if (!actor || !serviceId) return [];
      return actor.getServiceReviews(serviceId);
    },
    enabled: !!actor && !isFetching && !!serviceId,
  });
}

export function useAddReview() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ serviceId, rating, comment }: { serviceId: string; rating: bigint; comment: string | null }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addReview(serviceId, rating, comment);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['serviceReviews', variables.serviceId] });
      queryClient.invalidateQueries({ queryKey: ['service', variables.serviceId] });
      queryClient.invalidateQueries({ queryKey: ['services'] });
    },
  });
}
