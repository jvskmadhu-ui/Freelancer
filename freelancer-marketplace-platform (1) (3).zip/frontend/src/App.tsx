import { RouterProvider, createRouter, createRootRoute, createRoute, Outlet } from '@tanstack/react-router';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile } from './hooks/useCurrentUser';
import AppLayout from './components/layout/AppLayout';
import ProfileSetupModal from './components/auth/ProfileSetupModal';
import ServicesListPage from './pages/services/ServicesListPage';
import ServiceDetailPage from './pages/services/ServiceDetailPage';
import ServiceEditorPage from './pages/services/ServiceEditorPage';
import OrderDetailPage from './pages/orders/OrderDetailPage';
import OrderMessagesPage from './pages/orders/OrderMessagesPage';
import ClientDashboardPage from './pages/dashboards/ClientDashboardPage';
import ClientOrdersPage from './pages/dashboards/ClientOrdersPage';
import ClientMessagesPage from './pages/dashboards/ClientMessagesPage';
import FreelancerDashboardPage from './pages/dashboards/FreelancerDashboardPage';
import FreelancerOrdersPage from './pages/dashboards/FreelancerOrdersPage';
import FreelancerGigsPage from './pages/dashboards/FreelancerGigsPage';
import FreelancerMessagesPage from './pages/dashboards/FreelancerMessagesPage';
import AdminDashboardPage from './pages/dashboards/AdminDashboardPage';
import ProfilePage from './pages/dashboards/ProfilePage';
import PaymentSuccessPage from './pages/payments/PaymentSuccessPage';
import PaymentFailurePage from './pages/payments/PaymentFailurePage';
import LoadingState from './components/common/LoadingState';

function RootLayout() {
  return (
    <AppLayout>
      <Outlet />
    </AppLayout>
  );
}

const rootRoute = createRootRoute({
  component: RootLayout,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: ServicesListPage,
});

const servicesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/services',
  component: ServicesListPage,
});

const serviceDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/services/$serviceId',
  component: ServiceDetailPage,
});

const serviceEditorRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/services/edit/$serviceId',
  component: ServiceEditorPage,
});

const serviceCreateRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/services/new',
  component: ServiceEditorPage,
});

const orderDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/orders/$orderId',
  component: OrderDetailPage,
});

const orderMessagesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/orders/$orderId/messages',
  component: OrderMessagesPage,
});

const clientDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/client',
  component: ClientDashboardPage,
});

const clientOrdersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/client/orders',
  component: ClientOrdersPage,
});

const clientMessagesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/client/messages',
  component: ClientMessagesPage,
});

const freelancerDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/freelancer',
  component: FreelancerDashboardPage,
});

const freelancerOrdersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/freelancer/orders',
  component: FreelancerOrdersPage,
});

const freelancerGigsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/freelancer/gigs',
  component: FreelancerGigsPage,
});

const freelancerMessagesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/freelancer/messages',
  component: FreelancerMessagesPage,
});

const adminDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard/admin',
  component: AdminDashboardPage,
});

const profileRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/profile',
  component: ProfilePage,
});

const paymentSuccessRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/payment-success',
  component: PaymentSuccessPage,
});

const paymentFailureRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/payment-failure',
  component: PaymentFailurePage,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  servicesRoute,
  serviceDetailRoute,
  serviceEditorRoute,
  serviceCreateRoute,
  orderDetailRoute,
  orderMessagesRoute,
  clientDashboardRoute,
  clientOrdersRoute,
  clientMessagesRoute,
  freelancerDashboardRoute,
  freelancerOrdersRoute,
  freelancerGigsRoute,
  freelancerMessagesRoute,
  adminDashboardRoute,
  profileRoute,
  paymentSuccessRoute,
  paymentFailureRoute,
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  const { identity, isInitializing } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  if (isInitializing) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingState />
      </div>
    );
  }

  return (
    <>
      <RouterProvider router={router} />
      {showProfileSetup && <ProfileSetupModal />}
    </>
  );
}
