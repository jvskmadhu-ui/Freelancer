export function shortenPrincipal(principal: string, startChars = 8, endChars = 6): string {
  if (principal.length <= startChars + endChars) {
    return principal;
  }
  return `${principal.slice(0, startChars)}...${principal.slice(-endChars)}`;
}

export function getDisplayName(name: string | undefined, principal: string): string {
  if (name && name.trim()) {
    return name;
  }
  return shortenPrincipal(principal);
}
