import { useParams, useNavigate } from '@tanstack/react-router';
import { useGetProject } from '../../hooks/useQueries';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import LoadingState from '../../components/common/LoadingState';
import ErrorState from '../../components/common/ErrorState';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import OrderStatusBadge from '../../components/orders/OrderStatusBadge';
import { MessageSquare } from 'lucide-react';

export default function OrderDetailPage() {
  const { orderId } = useParams({ from: '/orders/$orderId' });
  const navigate = useNavigate();
  const { identity } = useInternetIdentity();
  const { data: project, isLoading, error, refetch } = useGetProject(orderId);

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="container py-12">
        <ErrorState message="Failed to load order" onRetry={() => refetch()} />
      </div>
    );
  }

  const isClient = identity?.getPrincipal().toText() === project.client.toText();
  const isFreelancer = identity?.getPrincipal().toText() === project.freelancer.toText();

  return (
    <div className="container max-w-4xl py-8">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-2xl mb-2">{project.title}</CardTitle>
                <p className="text-sm text-muted-foreground">Order ID: {project.id}</p>
              </div>
              <OrderStatusBadge status={project.orderStatus} />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Description</h3>
              <p className="text-muted-foreground">{project.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div>
                <p className="text-sm text-muted-foreground">Client</p>
                <p className="font-medium">{project.client.toText().slice(0, 12)}...</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Freelancer</p>
                <p className="font-medium">{project.freelancer.toText().slice(0, 12)}...</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Payment Status</p>
                <p className="font-medium capitalize">{project.paymentStatus}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="font-medium capitalize">{project.status}</p>
              </div>
            </div>

            {(isClient || isFreelancer) && (
              <div className="pt-4 border-t">
                <Button
                  onClick={() => navigate({ to: '/orders/$orderId/messages', params: { orderId } })}
                  className="w-full gap-2"
                >
                  <MessageSquare className="h-4 w-4" />
                  View Messages ({project.messages.length})
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
