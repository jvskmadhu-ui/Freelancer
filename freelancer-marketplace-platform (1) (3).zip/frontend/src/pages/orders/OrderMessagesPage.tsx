import { useState } from 'react';
import { useParams } from '@tanstack/react-router';
import { useGetProject, useGetProjectMessages, useAddMessage } from '../../hooks/useQueries';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import LoadingState from '../../components/common/LoadingState';
import ErrorState from '../../components/common/ErrorState';
import MessageThread from '../../components/messages/MessageThread';
import MessageComposer from '../../components/messages/MessageComposer';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { RefreshCw } from 'lucide-react';

export default function OrderMessagesPage() {
  const { orderId } = useParams({ from: '/orders/$orderId/messages' });
  const { identity } = useInternetIdentity();
  const { data: project, isLoading: projectLoading } = useGetProject(orderId);
  const { data: messages, isLoading: messagesLoading, refetch } = useGetProjectMessages(orderId);
  const addMessage = useAddMessage();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const handleSendMessage = async (content: string) => {
    await addMessage.mutateAsync({ projectId: orderId, content });
  };

  if (projectLoading || messagesLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="container py-12">
        <ErrorState message="Order not found" />
      </div>
    );
  }

  const isParticipant =
    identity?.getPrincipal().toText() === project.client.toText() ||
    identity?.getPrincipal().toText() === project.freelancer.toText();

  if (!isParticipant) {
    return (
      <div className="container py-12">
        <ErrorState message="You don't have access to these messages" />
      </div>
    );
  }

  return (
    <div className="container max-w-4xl py-8">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Messages for: {project.title}</CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <MessageThread messages={messages || []} currentUserPrincipal={identity?.getPrincipal().toText() || ''} />
          <MessageComposer onSend={handleSendMessage} isPending={addMessage.isPending} />
        </CardContent>
      </Card>
    </div>
  );
}
