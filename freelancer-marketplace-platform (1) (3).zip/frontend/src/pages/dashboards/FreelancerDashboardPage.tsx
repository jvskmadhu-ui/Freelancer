import { Link } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetUserServices, useGetProjectFeed } from '../../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Briefcase, ShoppingBag, DollarSign, MessageSquare } from 'lucide-react';
import LoadingState from '../../components/common/LoadingState';
import { Status } from '../../backend';

export default function FreelancerDashboardPage() {
  const { identity } = useInternetIdentity();
  const { data: gigs, isLoading: gigsLoading } = useGetUserServices(identity?.getPrincipal().toText());
  const { data: orders, isLoading: ordersLoading } = useGetProjectFeed(identity?.getPrincipal().toText());

  if (gigsLoading || ordersLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  const completedOrders = orders?.filter((o) => o.orderStatus === Status.completed) || [];
  const totalEarnings = completedOrders.reduce((sum, order) => sum + 0, 0);

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Freelancer Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link to="/dashboard/freelancer/gigs">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                My Gigs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{gigs?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Active services</p>
            </CardContent>
          </Card>
        </Link>

        <Link to="/dashboard/freelancer/orders">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5" />
                Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{orders?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total orders</p>
            </CardContent>
          </Card>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Earnings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">${totalEarnings.toFixed(2)}</p>
            <p className="text-sm text-muted-foreground">{completedOrders.length} completed</p>
          </CardContent>
        </Card>

        <Link to="/dashboard/freelancer/messages">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Messages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{orders?.reduce((sum, o) => sum + o.messages.length, 0) || 0}</p>
              <p className="text-sm text-muted-foreground">Total messages</p>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
