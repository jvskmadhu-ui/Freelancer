import { Link } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetProjectFeed } from '../../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import LoadingState from '../../components/common/LoadingState';
import EmptyState from '../../components/common/EmptyState';
import OrderStatusBadge from '../../components/orders/OrderStatusBadge';

export default function ClientOrdersPage() {
  const { identity } = useInternetIdentity();
  const { data: orders, isLoading } = useGetProjectFeed(identity?.getPrincipal().toText());

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="container py-12">
        <EmptyState title="No orders yet" description="Browse services and place your first order" />
      </div>
    );
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">My Orders</h1>
      <div className="space-y-4">
        {orders.map((order) => (
          <Link key={order.id} to="/orders/$orderId" params={{ orderId: order.id }}>
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle>{order.title}</CardTitle>
                  <OrderStatusBadge status={order.orderStatus} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Payment Status</p>
                    <p className="font-medium capitalize">{order.paymentStatus}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Messages</p>
                    <p className="font-medium">{order.messages.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
