import { Link, useNavigate } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetUserServices, useDeleteService } from '../../hooks/useQueries';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import LoadingState from '../../components/common/LoadingState';
import EmptyState from '../../components/common/EmptyState';
import ConfirmDialog from '../../components/common/ConfirmDialog';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';

export default function FreelancerGigsPage() {
  const { identity } = useInternetIdentity();
  const navigate = useNavigate();
  const { data: gigs, isLoading } = useGetUserServices(identity?.getPrincipal().toText());
  const deleteService = useDeleteService();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [serviceToDelete, setServiceToDelete] = useState<string | null>(null);

  const handleDeleteClick = (serviceId: string) => {
    setServiceToDelete(serviceId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!serviceToDelete) return;
    try {
      await deleteService.mutateAsync(serviceToDelete);
      toast.success('Service deleted successfully');
      setDeleteDialogOpen(false);
      setServiceToDelete(null);
    } catch (err: any) {
      toast.error(err.message || 'Failed to delete service');
    }
  };

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">My Gigs</h1>
        <Button onClick={() => navigate({ to: '/services/new' })} className="gap-2">
          <Plus className="h-4 w-4" />
          Create New Gig
        </Button>
      </div>

      {!gigs || gigs.length === 0 ? (
        <EmptyState title="No gigs yet" description="Create your first service to start earning" />
      ) : (
        <div className="space-y-4">
          {gigs.map((gig) => (
            <Card key={gig.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{gig.name}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">{gig.category}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate({ to: '/services/edit/$serviceId', params: { serviceId: gig.id } })}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteClick(gig.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Price</p>
                    <p className="font-medium">${Number(gig.price).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Rating</p>
                    <p className="font-medium">{gig.averageRating.toFixed(1)} ⭐</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Reviews</p>
                    <p className="font-medium">{gig.reviews.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={handleDeleteConfirm}
        title="Delete Service"
        description="Are you sure you want to delete this service? This action cannot be undone."
        isPending={deleteService.isPending}
      />
    </div>
  );
}
