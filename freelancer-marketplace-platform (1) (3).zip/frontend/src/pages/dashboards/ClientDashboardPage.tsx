import { Link } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetProjectFeed } from '../../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { ShoppingBag, MessageSquare, User } from 'lucide-react';
import LoadingState from '../../components/common/LoadingState';

export default function ClientDashboardPage() {
  const { identity } = useInternetIdentity();
  const { data: orders, isLoading } = useGetProjectFeed(identity?.getPrincipal().toText());

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Client Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/dashboard/client/orders">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5" />
                My Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{orders?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Total orders</p>
            </CardContent>
          </Card>
        </Link>

        <Link to="/dashboard/client/messages">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Messages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{orders?.reduce((sum, o) => sum + o.messages.length, 0) || 0}</p>
              <p className="text-sm text-muted-foreground">Total messages</p>
            </CardContent>
          </Card>
        </Link>

        <Link to="/profile">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Profile
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full">
                View Profile
              </Button>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
