import { Link } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetProjectFeed } from '../../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import LoadingState from '../../components/common/LoadingState';
import EmptyState from '../../components/common/EmptyState';
import { MessageSquare } from 'lucide-react';

export default function FreelancerMessagesPage() {
  const { identity } = useInternetIdentity();
  const { data: orders, isLoading } = useGetProjectFeed(identity?.getPrincipal().toText());

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  const ordersWithMessages = orders?.filter((o) => o.messages.length > 0) || [];

  if (ordersWithMessages.length === 0) {
    return (
      <div className="container py-12">
        <EmptyState title="No messages yet" description="Messages from clients will appear here" />
      </div>
    );
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">My Messages</h1>
      <div className="space-y-4">
        {ordersWithMessages.map((order) => (
          <Link key={order.id} to="/orders/$orderId/messages" params={{ orderId: order.id }}>
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  {order.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{order.messages.length} messages</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
