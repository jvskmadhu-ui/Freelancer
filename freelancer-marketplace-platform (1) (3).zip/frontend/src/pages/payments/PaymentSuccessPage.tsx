import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Link } from '@tanstack/react-router';
import { CheckCircle } from 'lucide-react';

export default function PaymentSuccessPage() {
  return (
    <div className="container max-w-2xl py-12">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-600">
            <CheckCircle className="h-6 w-6" />
            Payment Successful
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Your payment has been processed successfully. Your order is now active.</p>
          <div className="flex gap-4">
            <Link to="/dashboard/client/orders">
              <Button>View My Orders</Button>
            </Link>
            <Link to="/">
              <Button variant="outline">Browse More Services</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
