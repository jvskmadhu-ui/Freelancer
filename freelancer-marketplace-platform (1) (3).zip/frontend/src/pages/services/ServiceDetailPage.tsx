import { useParams, useNavigate } from '@tanstack/react-router';
import { useGetService, useGetServiceReviews, useCreateOrderWithInternalPayments } from '../../hooks/useQueries';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '../../hooks/useCurrentUser';
import LoadingState from '../../components/common/LoadingState';
import ErrorState from '../../components/common/ErrorState';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Star, Clock, DollarSign, User } from 'lucide-react';
import ReviewList from '../../components/reviews/ReviewList';
import { Role } from '../../backend';
import { toast } from 'sonner';

export default function ServiceDetailPage() {
  const { serviceId } = useParams({ from: '/services/$serviceId' });
  const navigate = useNavigate();
  const { identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: service, isLoading, error, refetch } = useGetService(serviceId);
  const { data: reviews } = useGetServiceReviews(serviceId);
  const createOrder = useCreateOrderWithInternalPayments();

  const isAuthenticated = !!identity;
  const isClient = userProfile?.role === Role.client;

  const handleOrderClick = async () => {
    if (!isAuthenticated) {
      toast.error('Please login to place an order');
      return;
    }

    if (!isClient) {
      toast.error('Only clients can place orders');
      return;
    }

    if (!service) return;

    try {
      const project = await createOrder.mutateAsync({
        freelancer: service.freelancer,
        title: service.name,
        price: service.price,
        serviceIds: [service.id],
      });
      toast.success('Order created successfully!');
      navigate({ to: '/orders/$orderId', params: { orderId: project.id } });
    } catch (err: any) {
      toast.error(err.message || 'Failed to create order');
    }
  };

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  if (error || !service) {
    return (
      <div className="container py-12">
        <ErrorState message="Failed to load service" onRetry={() => refetch()} />
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-3xl mb-2">{service.name}</CardTitle>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="px-2 py-1 bg-secondary rounded-md">{service.category}</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span>{service.averageRating.toFixed(1)}</span>
                      <span>({service.reviews.length} reviews)</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-muted-foreground whitespace-pre-wrap">{service.description}</p>
              </div>
              <div className="flex items-center gap-6 pt-4 border-t">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm">{service.duration || 'Flexible delivery'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm">Freelancer ID: {service.freelancer.toText().slice(0, 8)}...</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <ReviewList reviews={reviews || []} />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Price
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-3xl font-bold">${Number(service.price).toFixed(2)}</div>
              <Button
                className="w-full"
                size="lg"
                onClick={handleOrderClick}
                disabled={!isAuthenticated || !isClient || createOrder.isPending}
              >
                {createOrder.isPending ? 'Creating Order...' : 'Order Now'}
              </Button>
              {!isAuthenticated && (
                <p className="text-xs text-muted-foreground text-center">Login to place an order</p>
              )}
              {isAuthenticated && !isClient && (
                <p className="text-xs text-muted-foreground text-center">Only clients can place orders</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
