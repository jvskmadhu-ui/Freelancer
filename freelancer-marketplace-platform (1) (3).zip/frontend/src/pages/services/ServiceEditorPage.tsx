import { useState, useEffect } from 'react';
import { useParams, useNavigate } from '@tanstack/react-router';
import { useGetService, useAddService, useUpdateService } from '../../hooks/useQueries';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import { Label } from '../../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import LoadingState from '../../components/common/LoadingState';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

export default function ServiceEditorPage() {
  const params = useParams({ strict: false });
  const serviceId = 'serviceId' in params ? params.serviceId : undefined;
  const navigate = useNavigate();
  const { data: service, isLoading } = useGetService(serviceId);
  const addService = useAddService();
  const updateService = useUpdateService();

  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [duration, setDuration] = useState('');

  useEffect(() => {
    if (service) {
      setName(service.name);
      setCategory(service.category);
      setDescription(service.description);
      setPrice(Number(service.price).toString());
      setDuration(service.duration || '');
    }
  }, [service]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !category.trim() || !description.trim() || !price) {
      toast.error('Please fill in all required fields');
      return;
    }

    const priceValue = parseFloat(price);
    if (isNaN(priceValue) || priceValue <= 0) {
      toast.error('Please enter a valid price');
      return;
    }

    try {
      if (serviceId && service) {
        await updateService.mutateAsync({
          serviceId,
          updated: {
            ...service,
            name: name.trim(),
            category: category.trim(),
            description: description.trim(),
            price: BigInt(Math.round(priceValue * 100)) / 100n,
            duration: duration.trim() || undefined,
          },
        });
        toast.success('Service updated successfully!');
      } else {
        await addService.mutateAsync({
          name: name.trim(),
          category: category.trim(),
          description: description.trim(),
          price: BigInt(Math.round(priceValue * 100)) / 100n,
          duration: duration.trim() || null,
        });
        toast.success('Service created successfully!');
      }
      navigate({ to: '/dashboard/freelancer/gigs' });
    } catch (err: any) {
      toast.error(err.message || 'Failed to save service');
    }
  };

  if (isLoading && serviceId) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  const isPending = addService.isPending || updateService.isPending;

  return (
    <div className="container max-w-2xl py-8">
      <Card>
        <CardHeader>
          <CardTitle>{serviceId ? 'Edit Service' : 'Create New Service'}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Service Name *</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Logo Design"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Input
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="e.g., Design, Development, Writing"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your service in detail..."
                rows={6}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Price (USD) *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                min="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="0.00"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration">Delivery Time</Label>
              <Input
                id="duration"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="e.g., 3-5 days"
              />
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={isPending} className="flex-1">
                {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {serviceId ? 'Update Service' : 'Create Service'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate({ to: '/dashboard/freelancer/gigs' })}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
