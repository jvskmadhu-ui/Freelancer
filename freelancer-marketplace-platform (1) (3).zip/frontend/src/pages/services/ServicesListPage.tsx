import { useState } from 'react';
import { useGetServices } from '../../hooks/useQueries';
import { Link } from '@tanstack/react-router';
import ServiceCard from '../../components/services/ServiceCard';
import LoadingState from '../../components/common/LoadingState';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import { Input } from '../../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Search, SlidersHorizontal } from 'lucide-react';
import { Button } from '../../components/ui/button';

export default function ServicesListPage() {
  const { data: services, isLoading, error, refetch } = useGetServices();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('newest');

  if (isLoading) {
    return (
      <div className="container py-12">
        <LoadingState />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container py-12">
        <ErrorState message="Failed to load services" onRetry={() => refetch()} />
      </div>
    );
  }

  const categories = Array.from(new Set(services?.map((s) => s.category) || []));

  let filteredServices = services || [];

  if (searchTerm) {
    filteredServices = filteredServices.filter(
      (service) =>
        service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  if (categoryFilter !== 'all') {
    filteredServices = filteredServices.filter((service) => service.category === categoryFilter);
  }

  if (sortBy === 'price-low') {
    filteredServices = [...filteredServices].sort((a, b) => Number(a.price - b.price));
  } else if (sortBy === 'price-high') {
    filteredServices = [...filteredServices].sort((a, b) => Number(b.price - a.price));
  } else if (sortBy === 'newest') {
    filteredServices = [...filteredServices].sort((a, b) => Number(b.createdAt - a.createdAt));
  }

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Browse Freelance Services</h1>
        <p className="text-muted-foreground">Find the perfect service for your project</p>
      </div>

      <div className="mb-6 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {filteredServices.length === 0 ? (
        <EmptyState
          title="No services found"
          description="Try adjusting your search or filters"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service) => (
            <Link key={service.id} to="/services/$serviceId" params={{ serviceId: service.id }}>
              <ServiceCard service={service} />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
