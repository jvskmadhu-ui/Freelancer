# FreelanceHub - Freelancer Marketplace Frontend

A modern, full-featured freelancer marketplace built with React, TypeScript, and Tailwind CSS on the Internet Computer.

## Features

### Authentication & Roles
- Internet Identity integration for secure authentication
- Role-based access control (Client, Freelancer, Admin)
- First-login profile setup with role selection
- Protected routes based on user roles

### Service Management (Freelancers)
- Create, edit, and delete service gigs
- Set pricing, delivery time, and categories
- View service analytics and reviews
- Manage multiple active services

### Marketplace (Clients)
- Browse all available services
- Search by keyword
- Filter by category and price range
- Sort by newest, price (low to high, high to low)
- View detailed service information
- Place orders directly from service pages

### Order System
- Create orders from service detail pages
- Track order status (Placed → In Progress → Delivered → Completed)
- Role-based status transitions
- Payment status tracking
- Order history for both clients and freelancers

### Messaging
- Per-order messaging between client and freelancer
- Persistent message history
- Manual refresh and polling support
- Real-time-like UX without WebSockets

### Reviews & Ratings
- 1-5 star rating system
- Client reviews after order completion
- Average rating calculation
- Review display on service pages

### Dashboards
- **Client Dashboard**: Orders, messages, profile
- **Freelancer Dashboard**: Gigs, orders, earnings summary, messages
- **Admin Dashboard**: Basic user and service management

### Optional Stripe Integration
- Configuration-driven payment flow
- Graceful fallback when Stripe is not configured
- Payment success/failure handling
- Order payment status tracking

## Tech Stack

- **React 19** with TypeScript
- **TanStack Router** for client-side routing
- **TanStack React Query** for server state management
- **Tailwind CSS** for styling
- **shadcn/ui** component library
- **Internet Identity** for authentication
- **Motoko** backend on Internet Computer

## Getting Started

### Prerequisites

- Node.js 18+ and pnpm
- DFX (Internet Computer SDK)

### Installation

1. Install dependencies:
