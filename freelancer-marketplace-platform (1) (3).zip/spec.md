# Specification

## Summary
**Goal:** Build a Fiverr-style freelancer marketplace on the Internet Computer with Internet Identity auth, role-based experiences, gig discovery, orders, messaging, reviews, and optional Stripe payments.

**Planned changes:**
- Add Internet Identity sign-in, user profiles with role selection (Client/Freelancer) on first login, and Admin allowlist; enforce RBAC in backend mutations and frontend route guards.
- Implement Motoko canister models and CRUD APIs for gigs (title, description, category, price, delivery time, image URLs), plus public gig listing and gig detail retrieval.
- Add gig browse/search with keyword search, category and price-range filters, and sorting (newest, price low-to-high, price high-to-low).
- Implement orders: client creates order from a gig; persist orders with statuses (Pending/In Progress/Delivered/Completed) and role-based status transitions and access control.
- Implement order-linked messaging with persistent history and non-realtime UX (manual refresh and/or polling).
- Implement reviews/ratings: client can leave one 1–5 star review only after order completion; display reviews and average rating on gig pages.
- Build role-based dashboards:
  - Client: My Orders, Messages, Profile
  - Freelancer: My Gigs, Orders, Earnings summary, Messages
  - Admin: view users, view gigs, delete users/gigs (with confirmation)
- Add optional, configuration-driven Stripe payment step that fails gracefully; store paymentStatus on orders and allow non-crashing flow when Stripe is not configured.
- Apply a consistent, modern, responsive marketplace theme (non-blue/purple primary), reusable components, and consistent loading/error states using React Query.
- Seed backend with sample users/roles (client, freelancer, admin config) and multiple gigs so the UI has content immediately after deployment.
- Write README.md documenting features, configuration/env vars (admin allowlist + optional Stripe), and how to run locally with IC tooling.

**User-visible outcome:** Users can sign in with Internet Identity, choose a role, browse and search gigs, view gig details, clients can place orders (with optional payments), clients and freelancers can message per order, freelancers can manage gigs and order status, clients can complete orders and leave reviews, and admins can view/delete users and gigs—all in a responsive, consistently themed UI with seeded sample content.
